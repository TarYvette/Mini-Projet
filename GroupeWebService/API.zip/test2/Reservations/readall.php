<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if($_SERVER["REQUEST_METHOD"]=='GET'){
    include_once '../config/config.php';
    include_once '../models/Reservation.php';

    $dbase=new Database();
    $db=$dbase->getconnexion();

    $res=new Reservation($db);
    $stmt=$res->Showall();
    if($stmt->rowCount() > 0){
        $reservations = [];
        $reservations['reservations'] = [];
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);

            $reservat = [
                "Numreservation" => $NUMRESERVATION,
                "Numchambre" => $NUMCHAMBRE,
                "Numero" => $NUMCLIENT,
                "DateDebut" => $DATEDEBUT,
                "DateFin" => $DATEFIN,
                "Date" => $DATEPAYEAVANCE,
                "Montant" => $MONTANTARRHES
            ];
            $reservations['reservations'][] = $reservat;
        }
        // On envoie le code réponse 200 OK
        http_response_code(200);
        echo json_encode($reservations);
    }else{
        echo json_encode(["message" => "Aucune donnée corespondante!"]);
    }
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode non autorisée"]);
}

?>