<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER["REQUEST_METHOD"]=='GET'){
    include_once '../config/config.php';
    include_once '../models/Offres.php';

    $rid=$_GET['rid'];
    if(!empty($rid)){

        // $sql="SELECT R.NUMRESERVATION AS NUMERS,C.NUMCLIENT AS NUMCLENT,C.NOMCLIENT AS NOMC,C.PRENOMCLIENT AS PRENC,C.TELCLIENT AS TEL,
        // H.NOMH AS NOMH,CH.NUMCHAMBRE AS NC,CA.DESCRIPTION_ AS DESCRIP, R.DATEDEBUT AS DB, R.DATEFIN AS DF, R.DATEPAYEAVANCE AS DPA, 
        // R.MONTANTARRHES AS MONT FROM reservation R LEFT JOIN client C ON R.NUMCLIENT=C.NUMCLIENT LEFT JOIN hotel H ON H.NUMH=CH.NUMH 
        // LEFT JOIN chambre CH ON C.NUMCLIENT=CH.NUMCLIENT LEFT JOIN categorie CA ON CA.NUMCAT=CH.NUMCAT WHERE R.NUMRESERVATION=? ";
        $sql="SELECT R.NUMCHAMBRE AS NUMCHAMBRE, R.DATEDEBUT AS DEBUT, R.DATEFIN AS FIN,R.DATEPAYEAVANCE AS DPAVANCE,
        R.MONTANTARRHES AS MONTANT,C.NOMCLIENT AS NOM,C.PRENOMCLIENT AS PRENOM,C.TELCLIENT AS TELLEPHONE,
        CO.DATECONS AS DATECONSOMMATION,CO.HEURECON AS HEURE,CH.TELCHAMBRE AS TEL,CH.URLCHAMBRE AS URLCHAMBRE ,
        CA.DESCRIPTION_ AS CATEGORIE,H.NOMH AS HOTEL FROM reservation R LEFT JOIN client C ON R.NUMCLIENT=C.NUMCLIENT
        LEFT JOIN consommation CO ON CO.NUMCLIENT=C.NUMCLIENT LEFT JOIN chambre CH ON R.NUMCHAMBRE =CH.NUMCHAMBRE 
        LEFT JOIN categorie CA ON CA.NUMCAT=CH.NUMCAT LEFT JOIN hotel H ON CH.NUMH=H.NUMH WHERE R.NUMRESERVATION=?";

        $query = $this->connexion->prepare( $sql );

        $uid=htmlspecialchars(strip_tags($rid));

        $query->bindParam(1, $rid);
        $facture=[];
        $facture['FACTURE']=[];
        if($query->execute()){
            $stmt=$query;
            $facture['FACTURE'][]=[
                "NOM CLIENT"=>$stmt->NOM,
                "PRENOM CLIENT"=>$stmt->PRENNOM,
                "TELEPHONE CLIENT"=>$stmt->TELEPHONE,
                "NOM HOTEL"=>$stmt->HOTEL,
                "NUMREO CHAMBRE"=>$stmt->NUMCHAMBRE,
                "CATEGORIE CHAMBRE"=>$stmt->CATEGORIE,
                "TELEPHONE CHAMBRE"=>$stmt->TEL,
                "URL CHAMBRE"=>$stmt->URLCHAMBRE,
                "DATE DEBUT"=>$stmt->DEBUT,
                "DATE FIN"=>$stmt->FIN,
                "DATE PAYEMENT AVANCE"=>$stmt->DPAVANCE,
                "MONTANT"=> $stmt->MONTANT,
                "DATE DE CONSOMMATION"=>$stmt->DATECONSOMMATION,
                "HEURE DE CONSOMMATION"=>$stmt->HEURE,
            ];
            echo json_encode($facture);
        }else{
            echo json_encode(["message" => "Le Numéro de reservation entré n'existe pas!"]);
        }
        
    }
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}