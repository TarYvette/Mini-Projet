<?php
class Database{
    private $Host="localhost";
    private $db_name="Projet";
    private $db_username="root";
    private $db_password="";
    public $connexion;

    public function getconnexion(){

        $this-> connexion=null;
        try{
            $this->connexion=new PDO("mysql:host=".$this->Host."; dbname=".$this->db_name,$this->db_username,$this->db_password);
            $this->connexion->exec("set names utf8");
        }catch (PDOException $exception){
            echo"Erreur de connexion ".$exception->getMessage();
        }
        return $this->connexion;
    }
}

?>