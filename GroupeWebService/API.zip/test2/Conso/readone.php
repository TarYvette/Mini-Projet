<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER["REQUEST_METHOD"]=='GET'){
    include_once'../config/config.php';
    include_once'../models/conso.php';

    $dbase=new Database();
    $db=$dbase->getconnexion();
    $conso=new Conso($db);
    $donnees = json_decode(file_get_contents("php://input"));
    $uid=$_GET['uid'];
    if(!empty($uid)){
        $conso->numcons = $uid;
        $conso->Showone();
        if($conso->numcons != null){

            $conso = [
                "NUMERO" => $conso->numcons,
                "NUMCLIENT" => $conso->numclient,
                "DATE" => $conso->datecons,
                "HEURE" => $conso->heurecon,
                #"categories_nom" => $conso->categories_nom
            ];
            http_response_code(200);
            echo json_encode($conso);
        }else{
            http_response_code(404);
            echo json_encode(array("message" => "Cette consommation n'existe pas."));
        }
    }else{
        echo"Aucune Donnée reçue!";
    }

}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}

?>