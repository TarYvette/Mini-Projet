<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if($_SERVER["REQUEST_METHOD"]=='GET'){
    include_once '../config/config.php';
    include_once '../models/conso.php';

    $dbase=new Database();
    $db=$dbase->getconnexion();

    $user=new Conso($db);
    $stmt=$user->Showall();
    if($stmt->rowCount() > 0){
        $consos = [];
        $consos['CONSOMMATION'] = [];
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);

            $conso = [
                "Numero" => $NUMCONS,
                "Numclient" => $NUMCLIENT,
                "Date" => $DATECONS,
                "Heure" => $HEURECON,
            ];

            $consos['CONSOMMATION'][] = $conso;
        }

        // On envoie le code réponse 200 OK
        http_response_code(200);
        echo json_encode($consos);
    }
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}
?>