<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    if($_SERVER["REQUEST_METHOD"]=='POST'){
        include_once '../config/config.php';
        include_once '../models/conso.php';

        $dbase=new Database();
        $db=$dbase->getconnexion();
        $hot=new Conso($db);
        $numclient=$_GET['numclient'];
        $datecons=$_GET['datecons'];
        $heurecon=$_GET['heurecon'];
    
        $newcons=[
            "numclient" => $numclient,
            "date" => $datecons,
            "heure" => $heurecon,
        ];

        $newcons=json_encode($newcons);
        $newcons=json_decode($newcons);
        if(!empty($newcons)){
            $hot->numclient=$newcons->numclient;
            $hot->datecons=$newcons->date;
            $hot->heurecon=$newcons->heure;
        
            if($hot->Addconso()){
                http_response_code(200);
                echo json_encode(["message" => "La consommation a bien été enregistré!"]);
            }else{
                http_response_code(503);
                echo json_encode(["message" => "L'ajout de la nouvelle consommation n'a pas été effectué"]);
            }
            
        }else{
            echo json_encode(["message" => "Aucune donnee à enregistrer!"]);
        }
        
    }else{
        http_response_code(405);
        echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
    }
    
?>