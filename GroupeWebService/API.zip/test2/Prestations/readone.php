<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER["REQUEST_METHOD"]=='GET'){
    include_once '../config/config.php';
    include_once '../models/Prestation.php';

    $dbase=new Database();
    $db=$dbase->getconnexion();
    $Prestation=new Prestation($db);
    $donnees = json_decode(file_get_contents("php://input"));
    $uid=$_GET['uid'];
    if(!empty($uid)){
        $Prestation->Nump = $uid;
        $Prestation->Showone();
        if($Prestation->Nump != null){

            $Prest = [
                "NUMERO PRESTATION" => $Prestation->Nump,
                "CODE PRESTATION" => $Prestation->codep,
                "DESCRIPTON" => $Prestation->des,
                #"categories_nom" => $user->categories_nom
            ];
            http_response_code(200);
            echo json_encode($Prest);
        }else{
            http_response_code(404);
            echo json_encode(array("message" => "Cette Classe n'existe pas."));
        }
    }else{
        echo"Aucune Donnée reçue!";
    }

}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}

?>