<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER["REQUEST_METHOD"]=='GET'){
    include_once '../config/config.php';
    include_once '../models/Categorie.php';

    $dbase=new Database();
    $db=$dbase->getconnexion();
    $categorie=new Categorie($db);
    $donnees = json_decode(file_get_contents("php://input"));
    $uid=$_GET['uid'];
    if(!empty($uid)){
        $categorie->num = $uid;
        $categorie->Showone();
        if($categorie->num != null){

            $cat = [
                "Numero CATEGORIE" => $categorie->num,
                "Code CATEGORIE" => $categorie->code,
                "DESCRIPTION" => $categorie->desc
            ];
            http_response_code(200);
            echo json_encode($cat);
        }else{
            http_response_code(404);
            echo json_encode(array("message" => "Cette Categorie n'existe pas."));
        }
    }else{
        echo"Aucune Donnée : NUMERO de categorie non reçu!";
    }

}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}

?>