<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER["REQUEST_METHOD"]=='POST'){
    include_once '../config/config.php';
    include_once '../models/Categorie.php';

    $dbase=new Database();
    $db=$dbase->getconnexion();
    $cat=new Categorie($db);
    $code=$_GET['code'];
    $desc=$_GET['desc'];

    $newcat=[
        "code" => $code,
        "description" => $desc
    ];
    $newcat=json_encode($newcat);
    $newcat=json_decode($newcat);
    if(!empty($newcat)){
        #$user->id=$newcat->id;
        $cat->code=$newcat->code;
        $cat->desc=$newcat->description;
        
        if($cat->addcategorie()){
            http_response_code(200);
            echo json_encode(["message" => "La categorie a bien été enregistrée!"]);
        }else{
            http_response_code(503);
            echo json_encode(["message" => "L'ajout de la nouvelle categorie n'a pas été effectué"]);
        }
    }else{
        echo json_encode(["message" => "Aucune donnée à enregistrer!"]);
    }
    
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}

?>