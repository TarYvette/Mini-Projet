<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER["REQUEST_METHOD"]=='POST'){
    include_once '../config/config.php';
    include_once '../models/Offres.php';

    $dbase=new Database();
    $db=$dbase->getconnexion();
    $off=new Offre($db);
    $num=$_GET['num'];
    $numh=$_GET['numh'];

    $newoffer=[
        "Numero" => $num,
        "Numeroh" => $numh,
    ];
    $newoffer=json_encode($newoffer);
    $newoffer=json_decode($newoffer);
    if(!empty($newoffer)){
        #$user->id=$newoffer->id;
        $off->npres=$newoffer->Numero;
        $off->ncons=$newoffer->Numeroh;
        
        if($Off->addOffres()){
            http_response_code(200);
            echo json_encode(["message" => "L'Offres a bien été enregistrée!"]);
        }else{
            http_response_code(503);
            echo json_encode(["message" => "L'ajout de la nouvelle Offre n'a pas été effectué"]);
        }
    }else{
        echo json_encode(["message" => "Aucune donnée à enregistrer!"]);
    }
    
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}

?>