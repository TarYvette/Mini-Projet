<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if($_SERVER["REQUEST_METHOD"]=='GET'){
    include_once '../config/config.php';
    include_once '../models/Offres.php';

    $dbase=new Database();
    $db=$dbase->getconnexion();

    $offre=new Offre($db);
    $stmt=$offre->Showall();
    if($stmt->rowCount() > 0){
        $offres = [];
        $offres['OFFRES'] = [];
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);

            $off = [
                "Numero PRESTATION" => $NUMPRES,
                "Numero CONSOMMATION" => $NUMCONS,
            ];

            $offres['OFFRES'][] = $off;
        }

        // On envoie le code réponse 200 OK
        http_response_code(200);
        echo json_encode($offres);
    }
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}
?>