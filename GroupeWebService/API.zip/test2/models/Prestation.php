<?php

class Prestation{

    private $connexion;
    private $table="prestation";
    public $Nump;
    public $Codep;
    public $Des;


    public function __construct($db){
        
        $this->connexion=$db;
    }

    public function Showall(){
        $sql = "SELECT NUMPRES, CODEPRES , DESIGNATION_ FROM " . $this->table . " ORDER BY NUMPRES ASC";

        $query = $this->connexion->prepare($sql);

        $query->execute();

        return $query;
    }

    public function Showone(){
        $sql = "SELECT NUMPRES, CODEPRES , DESIGNATION_ FROM " . $this->table . " WHERE NUMPRES = ? LIMIT 0,1";

        $query = $this->connexion->prepare( $sql );

        $query->bindParam(1, $this->Nump);

        $query->execute();

        $row = $query->fetch(PDO::FETCH_ASSOC);
        if($row){
            $this->Nump = $row['NUMPRES'];
            $this->codep = $row['CODEPRES'];
            $this->des = $row['DESIGNATION_'];

        }
        
        #$this->categories_nom = $row['categories_nom'];
    }
    
    public function AddPrestation(){
        $sql = "INSERT INTO " . $this->table . " SET CODEPRES=:codep, DESIGNATION_=:des";

        $query = $this->connexion->prepare($sql);

        $this->Nump=htmlspecialchars(strip_tags($this->Nump));
        $this->codep=htmlspecialchars(strip_tags($this->codep));
        $this->des=htmlspecialchars(strip_tags($this->des));

        #$this->created_at=htmlspecialchars(strip_tags($this->created_at));

        #$query->bindParam(":Numc", $this->Nump);
        $query->bindParam(":Codep", $this->codep);
        $query->bindParam(":des", $this->des);

        #$query->bindParam(":created_at", $this->created_at);

        if($query->execute()){
            return true;
        }
        return false;
    }
    
    public function UpdatePrestation(){
        
        $sql = "UPDATE " . $this->table . " SET codep = :codep, des = :des WHERE NUMPRES=:Nump";
        
        $query = $this->connexion->prepare($sql);
        
        $this->Nump=htmlspecialchars(strip_tags($this->Nump));
        $this->codep=htmlspecialchars(strip_tags($this->codep));
        $this->des=htmlspecialchars(strip_tags($this->des));

        
        $query->bindParam(":Nump", $this->Nump);
        $query->bindParam(":codep", $this->codep);
        $query->bindParam(":des", $this->des);

        
        if($query->execute()){
            return true;
        }
        
        return false;
    }

    public function DelPrestation(){
        $sql = "DELETE FROM " . $this->table . " WHERE NUMPRES = ?";

        $query = $this->connexion->prepare( $sql );

        $this->Nump
        =htmlspecialchars(strip_tags($this->Nump));

        $query->bindParam(1, $this->Nump);

        if($query->execute()){
            return true;
        }
        return false;
    }
    
}