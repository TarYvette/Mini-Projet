<?php
class Relier{
    private $connexion;
    private $table="relier";
    public $numh;
    public $numpres;
    public $prixpres;
    
    
    public function __construct($db){
            
        $this->connexion=$db;
    }

    public function Showall(){
        $sql = "SELECT numh, numpres , prixpres FROM " . $this->table . " ORDER BY numh ASC";

        $query = $this->connexion->prepare($sql);

        $query->execute();

        return $query;
    }

    public function Showone(){
        $sql = "SELECT numh, numpres , prixpres FROM " . $this->table . " WHERE numh = ? LIMIT 0,1";

        $query = $this->connexion->prepare( $sql );

        $query->bindParam(1, $this->numh);

        $query->execute();

        $row = $query->fetch(PDO::FETCH_ASSOC);
        if($row){
            $this->numh = $row['NUMH'];
            $this->numpres = $row['NUMPRES'];
            $this->prixpres = $row['PRIXPRES'];    
        }

        #$this->categories_nom = $row['categories_nom'];
    }

    public function Addliaison(){
        $sql = "INSERT INTO " . $this->table . " SET NUMH=:numh, NUMPRES=:numpres, PRIXPRES=:prixpres";

        $query = $this->connexion->prepare($sql);

        $this->numh=htmlspecialchars(strip_tags($this->numh));
        $this->numpres=htmlspecialchars(strip_tags($this->numpres));
        $this->prixpres=htmlspecialchars(strip_tags($this->prixpres));
        #$this->created_at=htmlspecialchars(strip_tags($this->created_at));

        $query->bindParam(":numh", $this->numh);
        $query->bindParam(":numpres", $this->numpres);
        $query->bindParam(":prixpres", $this->prixpres);
        #$query->bindParam(":created_at", $this->created_at);

        if($query->execute()){
            return true;
        }
        return false;
    }

    public function Updateliaison(){

        $sql = "UPDATE " . $this->table . " SET NUMH=:numh, NUMPRES=:numpres, PRIXPRES=:prixpres WHERE NUMH = :numh";

        $query = $this->connexion->prepare($sql);

        $this->numh=htmlspecialchars(strip_tags($this->numh));
        $this->numpres=htmlspecialchars(strip_tags($this->numpres));
        $this->prixpres=htmlspecialchars(strip_tags($this->prixpres));
        #$this->created_at=htmlspecialchars(strip_tags($this->created_at));

        $query->bindParam(":numh", $this->numh);
        $query->bindParam(":numpres", $this->numpres);
        $query->bindParam(":prixpres", $this->prixpres);
        #$query->bindParam(":created_at", $this->created_at);

        if($query->execute()){
            return true;
        }
        return false;
    }

    public function Delliaison(){
        $sql = "DELETE FROM " . $this->table . " WHERE numh = ?";

        $query = $this->connexion->prepare( $sql );

        $this->numh=htmlspecialchars(strip_tags($this->numh));

        $query->bindParam(1, $this->numh);

        if($query->execute()){
            return true;
        }
        return false;
    }
}
?>