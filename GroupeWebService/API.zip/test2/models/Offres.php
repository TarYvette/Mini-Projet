<?php

class Offre{

    private $connexion;
    private $table="offrir";

    public $npres;
    public $ncons;

    public function __construct($db){
        $this->connexion=$db;
    }

    public function showall(){
        $sql = "SELECT NUMPRES , NUMCONS FROM " . $this->table . " ORDER BY NUMPRES ASC";

        $query = $this->connexion->prepare($sql);

        $query->execute();

        return $query;

    }

    public function showone(){
        $sql = "SELECT NUMPRES, NUMCONS FROM " . $this->table . " WHERE NUMPRES = ? LIMIT 0,1";

        $query = $this->connexion->prepare( $sql );

        $query->bindParam(1, $this->npres);

        $query->execute();

        $row = $query->fetch(PDO::FETCH_ASSOC);
        if($row){
            $this->npres = $row['NUMPRES'];
            $this->ncons = $row['NUMCONS'];
        }
    }

    public function addoffre(){
        $sql = "INSERT INTO " . $this->table . " SET NUMPRES=:num ,NUMCONS = :cons";

        $query = $this->connexion->prepare($sql);

        $this->npres=htmlspecialchars(strip_tags($this->npres));
        $this->ncons=htmlspecialchars(strip_tags($this->ncons));
        
        $query->bindParam(":num", $this->npres);
        $query->bindParam(":cons", $this->ncons);

        if($query->execute()){
            return true;
        }
        return false;
    }

    public function update(){
        $sql = "UPDATE " . $this->table . " SET NUMPRES= :num, NUMCONS = :cons WHERE NUMPRES = :num";
        
        $query = $this->connexion->prepare($sql);
        
        $this->npres=htmlspecialchars(strip_tags($this->npres));
        $this->ncons=htmlspecialchars(strip_tags($this->ncons));
        
        $query->bindParam(":num", $this->npres);
        $query->bindParam(":cons", $this->ncons);
        
        if($query->execute()){
            return true;
        }
        return false;
    }

    public function delete(){
        $sql = "DELETE FROM " . $this->table . " WHERE NUMPRESS = ?";

        $query = $this->connexion->prepare( $sql );

        $this->npres=htmlspecialchars(strip_tags($this->npres));

        $query->bindParam(1, $this->npres);

        if($query->execute()){
            return true;
        }
        return false;
    }
}

?>