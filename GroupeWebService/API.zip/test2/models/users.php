<?php

class Client{

    private $connexion;
    private $table="client";
    public $Num;
    public $nom;
    public $prenom;
    public $adresse;
    public $ville;
    public $cp;
    public $pays;
    public $tel;
    public $mail;
    public $pass;

    public function __construct($db){
        
        $this->connexion=$db;
    }

    public function Showall(){
        $sql = "SELECT NUMCLIENT, NOMCLIENT , PRENOMCLIENT, ADRESSECLIENT, VILLECLIENT, CP, PAYSCLIENT, TELCLIENT, MAILCLIENT FROM " . $this->table . " ORDER BY NUMCLIENT ASC";

        $query = $this->connexion->prepare($sql);

        $query->execute();

        return $query;
    }

    public function Showone(){
        $sql = "SELECT NUMCLIENT, NOMCLIENT , PRENOMCLIENT, ADRESSECLIENT, VILLECLIENT, CP, PAYSCLIENT, TELCLIENT, MAILCLIENT FROM " . $this->table . " WHERE NUMCLIENT = ? LIMIT 0,1";

        $query = $this->connexion->prepare( $sql );

        $query->bindParam(1, $this->Num);

        $query->execute();

        $row = $query->fetch(PDO::FETCH_ASSOC);
        if($row){
            $this->Num = $row['NUMCLIENT'];
            $this->nom = $row['NOMCLIENT'];
            $this->prenom = $row['PRENOMCLIENT'];
            $this->adresse = $row['ADRESSECLIENT'];
            $this->ville = $row['VILLECLIENT'];
            $this->cp = $row['CP'];
            $this->pays = $row['PAYSCLIENT'];
            $this->tel = $row['TELCLIENT'];
            $this->mail = $row['MAILCLIENT'];
        }
        
        #$this->categories_nom = $row['categories_nom'];
    }
    
    public function Adduser(){
        $sql = "INSERT INTO " . $this->table . " SET NOMCLIENT=:nom, PRENOMCLIENT=:prenom,ADRESSECLIENT=:adresse, VILLECLIENT=:ville , CP=:cp ,PAYSCLIENT=:pays, TELCLIENT=:tel, MAILCLIENT=:mail PASSCLIENT=:pass";

        $query = $this->connexion->prepare($sql);

        $this->Num=htmlspecialchars(strip_tags($this->Num));
        $this->nom=htmlspecialchars(strip_tags($this->nom));
        $this->prenom=htmlspecialchars(strip_tags($this->prenom));
        $this->adresse=htmlspecialchars(strip_tags($this->adresse));
        $this->ville=htmlspecialchars(strip_tags($this->ville));
        $this->cp=htmlspecialchars(strip_tags($this->cp));
        $this->pays=htmlspecialchars(strip_tags($this->pays));
        $this->tel=htmlspecialchars(strip_tags($this->tel));
        $this->mail=htmlspecialchars(strip_tags($this->mail));
        $this->pass=htmlspecialchars(strip_tags($this->pass));
        #$this->created_at=htmlspecialchars(strip_tags($this->created_at));

        #$query->bindParam(":Num", $this->Num);
        $query->bindParam(":nom", $this->nom);
        $query->bindParam(":prenom", $this->prenom);
        $query->bindParam(":adresse", $this->adresse);
        $query->bindParam(":ville", $this->ville);
        $query->bindParam(":cp", $this->cp);
        $query->bindParam(":pays", $this->pays);
        $query->bindParam(":tel", $this->tel);
        $query->bindParam(":mail", $this->mail);
        $query->bindParam(":pass", $this->pass);
        #$query->bindParam(":created_at", $this->created_at);

        if($query->execute()){
            return true;
        }
        return false;
    }
    
    public function Updateuser(){
        
        $sql = "UPDATE " . $this->table . " SET NOMCLIENT = :nom, PRENOMCLIENT = :prenom, ADRESSECLIENT = :adresse,VILLECLIENT=:ville, CP = :cp ,PAYSCLIENT=:pays, TELCLIENT=:tel, MAILCLIENT=:mail, PASSCLIENT=:pass WHERE NUMCLIENT = :Num";
        
        $query = $this->connexion->prepare($sql);
        
        $this->Num=htmlspecialchars(strip_tags($this->Num));
        $this->nom=htmlspecialchars(strip_tags($this->nom));
        $this->prenom=htmlspecialchars(strip_tags($this->prenom));
        $this->adresse=htmlspecialchars(strip_tags($this->adresse));
        $this->ville=htmlspecialchars(strip_tags($this->ville));
        $this->cp=htmlspecialchars(strip_tags($this->cp));
        $this->pays=htmlspecialchars(strip_tags($this->pays));
        $this->tel=htmlspecialchars(strip_tags($this->tel));
        $this->mail=htmlspecialchars(strip_tags($this->mail));
        $this->pass=htmlspecialchars(strip_tags($this->pass));
        
        $query->bindParam(":Num", $this->Num);
        $query->bindParam(":nom", $this->nom);
        $query->bindParam(":prenom", $this->prenom);
        $query->bindParam(":adresse", $this->adresse);
        $query->bindParam(":ville", $this->ville);
        $query->bindParam(":cp", $this->cp);
        $query->bindParam(":pays", $this->pays);
        $query->bindParam(":tel", $this->tel);
        $query->bindParam(":mail", $this->mail);
        $query->bindParam(":pass", $this->pass);
        
        if($query->execute()){
            return true;
        }
        
        return false;
    }

    public function Deluser(){
        $sql = "DELETE FROM " . $this->table . " WHERE NUMCLIENT = ?";

        $query = $this->connexion->prepare( $sql );

        $this->Num=htmlspecialchars(strip_tags($this->Num));

        $query->bindParam(1, $this->Num);

        if($query->execute()){
            return true;
        }
        return false;
    }

    public function login(){
        $sql="SELECT NOMCLIENT, PASSCLIENT FROM ".$this->table." WHERE MAILCLIENT = ?";
        $query = $this->connexion->prepare( $sql );

        $this->mail=htmlspecialchars(strip_tags($this->mail));

        $query->bindParam(1, $this->mail);

        $query->execute();
        return $query;
        
    }
    
}