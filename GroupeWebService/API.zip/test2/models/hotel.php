<?php
class Hotel{
    private $connexion;
    private $table="hotel";
    public $numh;
    public $numclasse;
    public $nomh;
    public $adresseh;
    public $cph;
    public $telh;
    public $img;

    public function __construct($db){
            
        $this->connexion=$db;
    }

    public function Showall(){
        $sql = "SELECT NUMH, NUMCLASSE , NOMH, ADRESSEH, CPH, TELH ,IMAGEH FROM " . $this->table . " ORDER BY NUMH ASC";

        $query = $this->connexion->prepare($sql);

        $query->execute();

        return $query;
    }

    public function Showone(){
        $sql = "SELECT NUMH, NUMCLASSE , NOMH, ADRESSEH, CPH, TELH FROM " . $this->table . " WHERE NUMH = ? LIMIT 0,1";

        $query = $this->connexion->prepare( $sql );

        $query->bindParam(1, $this->numh);

        $query->execute();

        $row = $query->fetch(PDO::FETCH_ASSOC);
        if($row){
            $this->numh = $row['NUMH'];
            $this->numclasse = $row['NUMCLASSE'];
            $this->nomh = $row['NOMH'];
            $this->adresseh = $row['ADRESSEH'];
            $this->cph = $row['CPH'];
            $this->telh = $row['TELH'];
            $this->img=$row['IMAGEH'];
        
        }
        
        #$this->categories_nom = $row['categories_nom'];
    }

    public function Addhotel(){
        $sql = "INSERT INTO " . $this->table . " SET NUMCLASSE=:numclasse, NOMH=:nomh,ADRESSEH=:adresseh, CPH=:cph , TELH=:telh , IMAGEH=:img";

        $query = $this->connexion->prepare($sql);

        $this->numh=htmlspecialchars(strip_tags($this->numh));
        $this->numclasse=htmlspecialchars(strip_tags($this->numclasse));
        $this->nomh=htmlspecialchars(strip_tags($this->nomh));
        $this->adresseh=htmlspecialchars(strip_tags($this->adresseh));
        $this->cph=htmlspecialchars(strip_tags($this->cph));
        $this->telh=htmlspecialchars(strip_tags($this->telh));
        $this->img=htmlspecialchars(strip_tags($this->img));

        #$query->bindParam(":numh", $this->numh);
        $query->bindParam(":numclasse", $this->numclasse);
        $query->bindParam(":nomh", $this->nomh);
        $query->bindParam(":adresseh", $this->adresseh);
        $query->bindParam(":cph", $this->cph);
        $query->bindParam(":telh", $this->telh);
        $query->bindParam(":img", $this->img);

        if($query->execute()){
            return true;
        }
        return false;
    }

    public function Updatehotel(){

        $sql = "UPDATE " . $this->table . " SET NUMCLASSE=:numclasse, NOMH=:nomh,ADRESSEH=:adresseh, CPH=:cph , TELH=:telh IMAGEH=:img WHERE NUMH = :numh";

        $query = $this->connexion->prepare($sql);

        $this->numh=htmlspecialchars(strip_tags($this->numh));
        $this->numclasse=htmlspecialchars(strip_tags($this->numclasse));
        $this->nomh=htmlspecialchars(strip_tags($this->nomh));
        $this->adresseh=htmlspecialchars(strip_tags($this->adresseh));
        $this->cph=htmlspecialchars(strip_tags($this->cph));
        $this->telh=htmlspecialchars(strip_tags($this->telh));
        $this->img=htmlspecialchars(strip_tags($this->img));

        $query->bindParam(":numh", $this->numh);
        $query->bindParam(":numclasse", $this->numclasse);
        $query->bindParam(":nomh", $this->nomh);
        $query->bindParam(":adresseh", $this->adresseh);
        $query->bindParam(":cph", $this->cph);
        $query->bindParam(":telh", $this->telh);
        $query->bindParam(":img", $this->img);

        if($query->execute()){
            return true;
        }
        return false;
    }

    public function Delhotel(){
        $sql = "DELETE FROM " . $this->table . " WHERE NUMH = ?";

        $query = $this->connexion->prepare( $sql );

        $this->numh=htmlspecialchars(strip_tags($this->numh));

        $query->bindParam(1, $this->numh);

        if($query->execute()){
            return true;
        }
        return false;
    }
}
?>