<?php

class Reservation{

    private $connexion;
    private $table="reservation";
    public $Numres;
    public $Numcha;
    public $Numcli;
    public $datdeb;
    public $datfin;
    public $datpay;
    public $mont;


    public function __construct($db){
        
        $this->connexion=$db;
    }

    public function Showall(){
        $sql = "SELECT NUMRESERVATION, NUMCHAMBRE , NUMCLIENT, DATEDEBUT, DATEFIN, DATEPAYEAVANCE, MONTANTARRHES FROM " . $this->table . " ORDER BY NUMRESERVATION ASC";

        $query = $this->connexion->prepare($sql);

        $query->execute();

        return $query;
    }

    public function Showone(){
        $sql = "SELECT NUMRESERVATION, NUMCHAMBRE , NUMCLIENT, DATEDEBUT, DATEFIN, DATEPAYEAVANCE, MONTANTARRHES FROM " . $this->table . " WHERE NUMCLIENT = ? LIMIT 0,1";

        $query = $this->connexion->prepare( $sql );

        $query->bindParam(1, $this->Num);

        $query->execute();

        $row = $query->fetch(PDO::FETCH_ASSOC);
        if($row){
            $this->Numres = $row['NUMRESERVATION'];
            $this->Numcha = $row['NUMCHAMBRE'];
            $this->Numcli = $row['NUMCLIENT'];
            $this->datdeb = $row['DATEDEBUT'];
            $this->datfin = $row['DATEFIN'];
            $this->datpay = $row['DATEPAYEAVANCE'];
            $this->mont = $row['MONTANTARRHES'];
        }
        
        #$this->categories_nom = $row['categories_nom'];
    }
    
    public function AddRes(){
        $sql = "INSERT INTO " . $this->table . " SET NUMCHAMBRE=:nom, NUMCLIENT=:prenom,DATEDEBUT=:adresse, DATEFIN=:ville , DATEPAYEAVANCE=:cp ,MONTANTARRHES=:pays";

        $query = $this->connexion->prepare($sql);

        $this->Numres=htmlspecialchars(strip_tags($this->Numres));
        $this->Numcha=htmlspecialchars(strip_tags($this->Numcha));
        $this->Numcli=htmlspecialchars(strip_tags($this->Numcli));
        $this->datdeb=htmlspecialchars(strip_tags($this->datdeb));
        $this->datfin=htmlspecialchars(strip_tags($this->datfin));
        $this->datpay=htmlspecialchars(strip_tags($this->datpay));
        $this->mont=htmlspecialchars(strip_tags($this->mont));

        #$this->created_at=htmlspecialchars(strip_tags($this->created_at));

        #$query->bindParam(":Num", $this->Numres);
        $query->bindParam(":nom", $this->Numcha);
        $query->bindParam(":prenom", $this->Numcli);
        $query->bindParam(":adresse", $this->datdeb);
        $query->bindParam(":ville", $this->datfin);
        $query->bindParam(":cp", $this->datpay);
        $query->bindParam(":pays", $this->mont);
        #$query->bindParam(":created_at", $this->created_at);

        if($query->execute()){
            return true;
        }
        return false;
    }
    
    public function Update(){
        
        $sql = "UPDATE " . $this->table . " SET NUMCHAMBRE=:nom, NUMCLIENT=:prenom,DATEDEBUT=:adresse, DATEFIN=:ville , DATEPAYEAVANCE=:cp ,MONTANTARRHES=:pays WHERE NUMRESERVATION=:Num";
        
        $query = $this->connexion->prepare($sql);
        
        $$this->Numres=htmlspecialchars(strip_tags($this->Numres));
        $this->Numcha=htmlspecialchars(strip_tags($this->Numcha));
        $this->Numcli=htmlspecialchars(strip_tags($this->Numcli));
        $this->datdeb=htmlspecialchars(strip_tags($this->datdeb));
        $this->datfin=htmlspecialchars(strip_tags($this->datfin));
        $this->datpay=htmlspecialchars(strip_tags($this->datpay));
        $this->mont=htmlspecialchars(strip_tags($this->mont));

        #$this->created_at=htmlspecialchars(strip_tags($this->created_at));

        $query->bindParam(":Num", $this->Numres);
        $query->bindParam(":nom", $this->Numcha);
        $query->bindParam(":prenom", $this->Numcli);
        $query->bindParam(":adresse", $this->datdeb);
        $query->bindParam(":ville", $this->datfin);
        $query->bindParam(":cp", $this->datpay);
        $query->bindParam(":pays", $this->mont);
        #$query->bindParam(":created_at", $this->created_at);
        
        if($query->execute()){
            return true;
        }
        
        return false;
    }

    public function Delete(){
        $sql = "DELETE FROM " . $this->table . " WHERE NUMRESERVATION = ?";

        $query = $this->connexion->prepare( $sql );

        $this->Num=htmlspecialchars(strip_tags($this->Num));

        $query->bindParam(1, $this->Num);

        if($query->execute()){
            return true;
        }
        return false;
    }
    
}