<?php
class Chambre{

    private $connexion;
    private $table="chambre";

    public $num;
    public $numh;
    public $numc;
    public $tel;
    public $url;

    public function __construct($bd){
        $this->connexion=$bd;
    }

    public function showall(){
        $sql = "SELECT NUMCHAMBRE,NUMH,NUMCAT,TELCHAMBRE,URLCHAMBRE FROM " . $this->table . " ORDER BY NUMCHAMBRE ASC";

        $query = $this->connexion->prepare($sql);

        $query->execute();

        return $query;
    }

    public function showone(){
        $sql = "SELECT NUMCHAMBRE,NUMH,NUMCAT,TELCHAMBRE,URLCHAMBRE FROM " . $this->table . " WHERE NUMCHAMBRE = ? LIMIT 0,1";

        $query = $this->connexion->prepare( $sql );

        $query->bindParam(1, $this->num);

        $query->execute();

        $row = $query->fetch(PDO::FETCH_ASSOC);
        if($row){
            $this->num = $row['NUMCHAMBRE'];
            $this->numh = $row['NUMH'];
            $this->numc = $row['NUMCAT'];
            $this->tel = $row['TELCHAMBRE'];
            $this->url=$row['URLCHAMBRE'];
            
        }
        
    }

    public function update(){
        $sql = "UPDATE " . $this->table . " SET NUMH = :numh, NUMCAT = :numc,TELCHAMBRE=:tel URLCHAMBRE=:url WHERE NUMCHAMBRE = :num";
        
        $query = $this->connexion->prepare($sql);
        
        $this->num=htmlspecialchars(strip_tags($this->num));
        $this->numh=htmlspecialchars(strip_tags($this->numh));
        $this->numc=htmlspecialchars(strip_tags($this->numc));
        $this->tel=htmlspecialchars(strip_tags($this->tel));
        $this->url=htmlspecialchars(strip_tags($this->url));
        
        $query->bindParam(":num", $this->num);
        $query->bindParam(":numh", $this->numh);
        $query->bindParam(":numc", $this->numc);
        $query->bindParam(":tel", $this->tel);
        $query->bindParam(":url", $this->url);
        
        if($query->execute()){
            return true;
        }
        
        return false;
    }

    public function addchambre(){
        $sql = "INSERT INTO " . $this->table . " SET NUMH = :numh, NUMCAT = :numc,TELCHAMBRE=:tel URLCHAMBRE=:url";

        $query = $this->connexion->prepare($sql);

        $this->num=htmlspecialchars(strip_tags($this->num));
        $this->numh=htmlspecialchars(strip_tags($this->numh));
        $this->numc=htmlspecialchars(strip_tags($this->numc));
        $this->tel=htmlspecialchars(strip_tags($this->tel));
        $this->url=htmlspecialchars(strip_tags($this->url));
        
        #$query->bindParam(":num", $this->num);
        $query->bindParam(":numh", $this->numh);
        $query->bindParam(":numc", $this->numc);
        $query->bindParam(":tel", $this->tel);
        $query->bindParam(":url", $this->url);

        if($query->execute()){
            return true;
        }
        return false;
    }

    public function delchambre(){
        $sql = "DELETE FROM " . $this->table . " WHERE NUMCHAMBRE = ?";

        $query = $this->connexion->prepare( $sql );

        $this->num=htmlspecialchars(strip_tags($this->num));

        $query->bindParam(1, $this->num);

        if($query->execute()){
            return true;
        }
        return false;
    }
}

?>