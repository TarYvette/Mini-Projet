<?php
class Conso{
    private $connexion;
    private $table="consommation";
    public $numcons;
    public $numclient;
    public $datecons;
    public $heurecon;
    
    public function __construct($db){
            
        $this->connexion=$db;
    }

    public function Showall(){
        $sql = "SELECT NUMCONS, NUMCLIENT , DATECONS, HEURECON FROM " . $this->table . " ORDER BY NUMCONS ASC";

        $query = $this->connexion->prepare($sql);

        $query->execute();

        return $query;
    }

    public function Showone(){
        $sql = "SELECT NUMCONS, NUMCLIENT , DATECONS, HEURECON FROM " . $this->table . " WHERE NUMCONS = ? LIMIT 0,1";

        $query = $this->connexion->prepare( $sql );

        $query->bindParam(1, $this->numcons);

        $query->execute();

        $row = $query->fetch(PDO::FETCH_ASSOC);
        if($row){
            $this->numcons = $row['NUMCONS'];
            $this->numclient = $row['NUMCLIENT'];
            $this->datecons = $row['DATECONS'];
            $this->heurecon = $row['HEURECON'];
            
        }
        
        #$this->categories_nom = $row['categories_nom'];
    }

    public function Addconso(){
        $sql = "INSERT INTO " . $this->table . " SET NUMCLIENT=:numclient, DATECONS=:datecons,HEURECON=:heurecon";

        $query = $this->connexion->prepare($sql);

        $this->numcons=htmlspecialchars(strip_tags($this->numcons));
        $this->numclient=htmlspecialchars(strip_tags($this->numclient));
        $this->datecons=htmlspecialchars(strip_tags($this->datecons));
        $this->heurecon=htmlspecialchars(strip_tags($this->heurecon));
        #$this->created_at=htmlspecialchars(strip_tags($this->created_at));

        #$query->bindParam(":numcons", $this->numcons);
        $query->bindParam(":numclient", $this->numclient);
        $query->bindParam(":datecons", $this->datecons);
        $query->bindParam(":heurecon", $this->heurecon);
        #$query->bindParam(":created_at", $this->created_at);

        if($query->execute()){
            return true;
        }
        return false;
    }

    public function Updateconso(){

        $sql = "UPDATE " . $this->table . " SET NUMCLIENT=:numclient, DATECONS=:datecons,HEURECON=:heurecon WHERE NUMCONS = :numcons";

        $query = $this->connexion->prepare($sql);

        $this->numcons=htmlspecialchars(strip_tags($this->numcons));
        $this->numclient=htmlspecialchars(strip_tags($this->numclient));
        $this->datecons=htmlspecialchars(strip_tags($this->datecons));
        $this->heurecon=htmlspecialchars(strip_tags($this->heurecon));
        #$this->created_at=htmlspecialchars(strip_tags($this->created_at));

        $query->bindParam(":numcons", $this->numcons);
        $query->bindParam(":numclient", $this->numclient);
        $query->bindParam(":datecons", $this->datecons);
        $query->bindParam(":heurecon", $this->heurecon);
        #$query->bindParam(":created_at", $this->created_at);

        if($query->execute()){
            return true;
        }
        return false;
    }

    public function Delconso(){
        $sql = "DELETE FROM " . $this->table . " WHERE numcons = ?";

        $query = $this->connexion->prepare( $sql );

        $this->numcons=htmlspecialchars(strip_tags($this->numcons));

        $query->bindParam(1, $this->numcons);

        if($query->execute()){
            return true;
        }
        return false;
    }

    public function Facture(){


    }
}
?>