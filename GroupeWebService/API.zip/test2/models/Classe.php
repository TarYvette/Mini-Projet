<?php

class Classe{

    private $connexion;
    private $table="classe";
    public $Numc;
    public $Nbe;
    public $Car;


    public function __construct($db){
        
        $this->connexion=$db;
    }

    public function Showall(){
        $sql = "SELECT NUMCLASSE, NBREETOILE , CARACTERISTIQUE FROM " . $this->table . " ORDER BY NUMCLASSE ASC";

        $query = $this->connexion->prepare($sql);

        $query->execute();

        return $query;
    }

    public function Showone(){
        $sql = "SELECT NUMCLASSE, NBREETOILE , CARACTERISTIQUE FROM " . $this->table . " WHERE NUMCLASSE = ? LIMIT 0,1";

        $query = $this->connexion->prepare( $sql );

        $query->bindParam(1, $this->Numc);

        $query->execute();

        $row = $query->fetch(PDO::FETCH_ASSOC);
        if($row){
            $this->Numc = $row['NUMCLASSE'];
            $this->Nbe = $row['NBREETOILE'];
            $this->Car = $row['CARACTERISTIQUE'];

        }
        
        #$this->categories_nom = $row['categories_nom'];
    }
    
    public function Addclasse(){
        
        $sql = "INSERT INTO " . $this->table . " SET NBREETOILE=:Nbe, CARACTERISTIQUE=:Car";

        $query = $this->connexion->prepare($sql);

        $this->Numc=htmlspecialchars(strip_tags($this->Numc));
        $this->Nbe=htmlspecialchars(strip_tags($this->Nbe));
        $this->Car=htmlspecialchars(strip_tags($this->Car));

        #$this->created_at=htmlspecialchars(strip_tags($this->created_at));

        #$query->bindParam(":Numc", $this->Numc);
        $query->bindParam(":Nbe", $this->Nbe);
        $query->bindParam(":Car", $this->Car);

        #$query->bindParam(":created_at", $this->created_at);

        if($query->execute()){
            return true;
        }
        return false;
    }
    
    public function Updateclasse(){
        
        $sql = "UPDATE " . $this->table . " SET NBREETOILE = :Nbe, Car = :Car WHERE NUMCLASSE=:Numc";
        
        $query = $this->connexion->prepare($sql);
        
        $this->Numc=htmlspecialchars(strip_tags($this->Numc));
        $this->Nbe=htmlspecialchars(strip_tags($this->Nbe));
        $this->Car=htmlspecialchars(strip_tags($this->Car));

        
        $query->bindParam(":Numc", $this->Numc);
        $query->bindParam(":Nbe", $this->Nbe);
        $query->bindParam(":Car", $this->Car);

        
        if($query->execute()){
            return true;
        }
        
        return false;
    }

    public function Delclasse(){
        $sql = "DELETE FROM " . $this->table . " WHERE NUMCLASSSE = ?";

        $query = $this->connexion->prepare( $sql );

        $this->Numc=htmlspecialchars(strip_tags($this->Numc));

        $query->bindParam(1, $this->Numc);

        if($query->execute()){
            return true;
        }
        return false;
    }
    
}
?>