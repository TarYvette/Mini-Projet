<?php
class Categorie{

    private $connexion;
    private $table="categorie";

    public $num;
    public $code;
    public $desc;

    public function __construct($db){
        $this->connexion=$db;
    }

    public function showall(){
        $sql = "SELECT NUMCAT,CODECAT,DESCRIPTION_ FROM " . $this->table . " ORDER BY NUMCAT ASC";

        $query = $this->connexion->prepare($sql);

        $query->execute();

        return $query;
    }

    public function showone(){
        $sql = "SELECT NUMCAT,CODECAT,DESCRIPTION_ FROM " . $this->table . " WHERE NUMCAT = ? LIMIT 0,1";

        $query = $this->connexion->prepare( $sql );

        $query->bindParam(1, $this->num);

        $query->execute();

        $row = $query->fetch(PDO::FETCH_ASSOC);
        if($row){
            $this->num = $row['NUMCAT'];
            $this->code = $row['CODECAT'];
            $this->desc = $row['DESCRIPTION_'];
        }
        
    }

    public function addcategorie(){
        $sql = "INSERT INTO " . $this->table . " SET CODECAT = :code, DESCRIPTION_ = :desc";

        $query = $this->connexion->prepare($sql);

        #$this->num=htmlspecialchars(strip_tags($this->num));
        $this->code=htmlspecialchars(strip_tags($this->code));
        $this->desc=htmlspecialchars(strip_tags($this->desc));
        
        #$query->bindParam(":num", $this->num);
        $query->bindParam(":code", $this->code);
        $query->bindParam(":desc", $this->desc);

        if($query->execute()){
            return true;
        }
        return false;
    }

    public function update(){
        $sql = "UPDATE " . $this->table . " SET CODECAT = :code, DESCRIPTION_ = :desc WHERE NUMCAT = :num";
        
        $query = $this->connexion->prepare($sql);
        
        $this->num=htmlspecialchars(strip_tags($this->num));
        $this->code=htmlspecialchars(strip_tags($this->code));
        $this->desc=htmlspecialchars(strip_tags($this->desc));
        
        $query->bindParam(":num", $this->num);
        $query->bindParam(":code", $this->code);
        $query->bindParam(":desc", $this->desc);
        
        if($query->execute()){
            return true;
        }
        return false;
    }

    public function delete(){
        $sql = "DELETE FROM " . $this->table . " WHERE NUMCAT = ?";

        $query = $this->connexion->prepare( $sql );

        $this->num=htmlspecialchars(strip_tags($this->num));

        $query->bindParam(1, $this->num);

        if($query->execute()){
            return true;
        }
        return false;
    }
}


?>