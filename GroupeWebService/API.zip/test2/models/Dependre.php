<?php

class Dependre{

    private $connexion;
    private $table="dependre";
    public $Numc;
    public $Numcat;
    public $Prix;


    public function __construct($db){
        
        $this->connexion=$db;
    }

    public function Showall(){
        $sql = "SELECT NUMCLASSE, NUMCAT , PRIXCHAMBRE FROM " . $this->table . " ORDER BY NUMCLASSE ASC";

        $query = $this->connexion->prepare($sql);

        $query->execute();

        return $query;
    }

    public function Showone(){
        $sql = "SELECT NUMCLASSE, NUMCAT , PRIXCHAMBRE FROM " . $this->table . " WHERE NUMCLASSE = ? LIMIT 0,1";

        $query = $this->connexion->prepare( $sql );

        $query->bindParam(1, $this->Numc);

        $query->execute();

        $row = $query->fetch(PDO::FETCH_ASSOC);
        if($row){ 
            $this->Numc = $row['NUMCLASSE'];
            $this->Numcat = $row['NUMCAT'];
            $this->Prix = $row['PRIXCHAMBRE'];

        }
        
        #$this->categories_nom = $row['categories_nom'];
    }
    
    public function AddDependre(){
        $sql = "INSERT INTO " . $this->table . " SET NUMCLASSE=:Numc, NUMCAT=:Numcat, PRIXCHAMBRE=:Prix";

        $query = $this->connexion->prepare($sql);

        $this->Numc=htmlspecialchars(strip_tags($this->Numc));
        $this->Numcat=htmlspecialchars(strip_tags($this->Numcat));
        $this->Prix=htmlspecialchars(strip_tags($this->Prix));

        #$this->created_at=htmlspecialchars(strip_tags($this->created_at));

        $query->bindParam(":Numc", $this->Numc);
        $query->bindParam(":Numcat", $this->Numcat);
        $query->bindParam(":Prix", $this->Prix);

        #$query->bindParam(":created_at", $this->created_at);

        if($query->execute()){
            return true;
        }
        return false;
    }
    
    public function UpdateDependre(){
        
        $sql = "UPDATE " . $this->table . " SET NUMCAT = :Numcat, PRIXCHAMBRE = :Prix WHERE NUMCAT=:Numc";
        
        $query = $this->connexion->prepare($sql);
        
        $this->Numc=htmlspecialchars(strip_tags($this->Numc));
        $this->Nbe=htmlspecialchars(strip_tags($this->Numcat));
        $this->Prix=htmlspecialchars(strip_tags($this->Prix));

        
        $query->bindParam(":Numc", $this->Numc);
        $query->bindParam(":Numcat", $this->Numcat);
        $query->bindParam(":Prix", $this->Prix);

        
        if($query->execute()){
            return true;
        }
        
        return false;
    }

    public function DelDependre(){
        $sql = "DELETE FROM " . $this->table . " WHERE Numc = ?";

        $query = $this->connexion->prepare( $sql );

        $this->Numc=htmlspecialchars(strip_tags($this->Numc));

        $query->bindParam(1, $this->Numc);

        if($query->execute()){
            return true;
        }
        return false;
    }
    
}