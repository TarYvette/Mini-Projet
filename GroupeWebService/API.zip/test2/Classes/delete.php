<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER["REQUEST_METHOD"]=='DELETE'){
    include_once '../config/config.php';
    include_once '../models/Classe.php';

    $dbase=new Database();
    $db=$dbase->getconnexion();
    $classe=new Classe($db);
    $uid=$_GET['id'];
    if(!empty($uid)){
        $classe->id=$uid;
        if($classe->DelClasse()){
            http_response_code(200);
            echo json_encode(["message" => " supprimé avec succes!"]);
        }else{
            http_response_code(503);
            echo json_encode(["message" => "Suppression non éffectuée!"]);
        }
    }else{
        echo json_encode(["message" => "Aucune donnée : ID non reçu!"]);
    }
    
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}
?>