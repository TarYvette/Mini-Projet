<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER["REQUEST_METHOD"]=='POST'){
    include_once '../config/config.php';
    include_once '../models/chambre.php';

    $dbase=new Database();
    $db=$dbase->getconnexion();
    $chambre=new Chambre($db);

    $numh=$_GET['numh'];
    $numc=$_GET['numc'];
    $tel=$_GET['tel'];
    $url=$_GET['url'];

    $newroom=[
        "Numeroh" => $numh,
        "Categorie" => $numc,
        "Telephone" => $tel,
        "Url"=>$url
    ];
    $newroom=json_encode($newroom);
    echo$newroom;
    $newroom=json_decode($newroom);
    if(!empty($newroom)){
        #$user->id=$newroom->id;
        $chambre->numh=$newroom->Numeroh;
        $chambre->numc=$newroom->Categorie;
        $chambre->tel=$newroom->Telephone;
        $chambre->url=$newroom->Url;
        
        if($chambre->addchambre()){
            http_response_code(200);
            echo json_encode(["message" => "La chambre a bien été enregistrée!"]);
        }else{
            http_response_code(503);
            echo json_encode(["message" => "L'ajout de la nouvelle Chambre n'a pas été effectué"]);
        }
    }else{
        echo json_encode(["message" => "Aucune donnée à enregistrer!"]);
    }
    
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}

?>