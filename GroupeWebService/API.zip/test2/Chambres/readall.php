<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if($_SERVER["REQUEST_METHOD"]=='GET'){
    include_once '../config/config.php';
    include_once '../models/chambre.php';

    $dbase=new Database();
    $db=$dbase->getconnexion();

    $chambre=new Chambre($db);
    $stmt=$chambre->Showall();
    if($stmt->rowCount() > 0){
        $chambres = [];
        $chambres['CHAMBRES'] = [];
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);

            $cham = [
                "Numero de chambre" => $NUMCHAMBRE,
                "Numero de l'hotel" => $NUMH,
                "Categorie" => $NUMCAT,
                "Telephone" => $TELCHAMBRE,
                "URL"=>$URLCHAMBRE
            ];

            $chambres['CHAMBRES'][] = $cham;
        }

        // On envoie le code réponse 200 OK
        http_response_code(200);
        echo json_encode($chambres);
    }
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}
?>