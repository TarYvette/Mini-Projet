<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if($_SERVER['REQUEST_METHOD'] == 'PUT'){
    include_once '../config/config.php';
    include_once '../models/chambre.php';

    $database = new Database();
    $db = $database->getConnexion();
    $chambre = new Chambre($db);
    $num=$_GET['num'];
    $numh=$_GET['numh'];
    $numc=$_GET['numc'];
    $tel=$_GET['tel'];
    $url=$_GET['url'];
    $newinfo=[
        "numero"=>$num,
        "numeroh"=>$numh,
        "categorie"=>$numc,
        "Telephone"=>$tel,
        "Url"=>$url
    ];
    $newinfo=json_encode($newinfo);
    $newinfo=json_decode($newinfo);
    #$newinfo = json_decode(file_get_contents("php://input"));
    if(!empty($newinfo)){

        $chambre->num = $newinfo->numeroh;
        $chambre->numh = $newinfo->numeroh;
        $chambre->numc = $newinfo->categorie;
        $chambre->tel = $newinfo->Telephone;
        $chambre->url=$newinfo->Url;

        if($chambre->Update()){
            http_response_code(200);
            echo json_encode(["message" => "La modification a bien été effectuée"]);
        }else{
            http_response_code(503);
            echo json_encode(["message" => "La modification n'a pas été effectuée"]);         
        }
    }else{
        echo json_encode(["message" => "Aucune donnée reçue!"]);
    }
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}