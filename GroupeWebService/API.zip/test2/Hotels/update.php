<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if($_SERVER['REQUEST_METHOD'] == 'PUT'){
    include_once '../config/config.php';
    include_once '../models/hotel.php';

    $database = new Database();
    $db = $database->getConnexion();
    $user = new Hotel($db);
    $numh=$_GET['numh'];
    $numclasse=$_GET['numclasse'];
    $nomh=$_GET['nomh'];
    $adresseh=$_GET['adresseh'];
    $cph=$_GET['cph'];
    $telh=$_GET['telh'];
    $img=$_GET['img'];
    
    $newinfo=[
        "numero"=>$numh,
        "numclasse"=>$numclasse,
        "nom"=>$nomh,
        "adresse"=>$adresseh,
        "CodePostal"=>$cph,
        "Telephone"=>$telh,
        "Image"=>$img
    ];

    $newinfo=json_encode($newinfo);
    $newinfo=json_decode($newinfo);
    #$newinfo = json_decode(file_get_contents("php://input"));
    if(!empty($newinfo)){

        $user->numh = $newinfo->numero;
        $user->numclasse = $newinfo->numclasse;
        $user->nomh = $newinfo->nom;
        $user->adresseh = $newinfo->adresse;
        $user->cph = $newinfo->CodePostal;
        $user->telh = $newinfo->Telephone;
        $user->img=$newinfo->Image;

        if($user->Updatehotel()){
            http_response_code(200);
            echo json_encode(["message" => "La modification a bien été effectuée"]);
        }else{
            http_response_code(503);
            echo json_encode(["message" => "La modification n'a pas été effectuée"]);         
        }
    }else{
        echo json_encode(["message" => "La modification n'a pas été effectuée"]);
    }
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}