<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    if($_SERVER["REQUEST_METHOD"]=='POST'){
        include_once'../config/config.php';
        include_once'../models/hotel.php';

        $dbase=new Database();
        $db=$dbase->getconnexion();
        $hot=new Hotel($db);

        $numclasse=$_GET['numclasse'];
        $nomh=$_GET['nomh'];
        $adresseh=$_GET['adresseh'];
        $cph=$_GET['cph'];
        $telh=$_GET['telh'];
        $img=$_GET['img'];

        $newhot=[
            "Numclasse" => $numclasse,
            "Nom" => $nomh,
            "Adresse" => $adresseh,
            "CodePostal" => $cph,
            "Telephone" => $telh,
            "Image"=>$img
        ];

        $newhot=json_encode($newhot);
        $newhot=json_decode($newhot);
        if(!empty($newhot)){
            $hot->numclasse=$newhot->Numclasse;
            $hot->nomh=$newhot->Nom;
            $hot->adresseh=$newhot->Adresse;
            $hot->cph=$newhot->CodePostal;
            $hot->telh=$newhot->Telephone;
            $hot->img=$newhot->Image;

            if($hot->Addhotel()){
                http_response_code(200);
                echo json_encode(["message" => "L'hotel a bien été enregistré!"]);
            }else{
                http_response_code(503);
                echo json_encode(["message" => "L'ajout du nouvel hotel n'a pas été effectué"]);
            }
            
        }else{
            echo json_encode(["message" => "Aucune donnee à enregistrer!"]);
        }
        
    }else{
        http_response_code(405);
        echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
    }
    
?>