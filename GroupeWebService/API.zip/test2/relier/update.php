<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if($_SERVER['REQUEST_METHOD'] == 'PUT'){
    include_once '../config/config.php';
    include_once '../models/relier.php';

    $database = new Database();
    $db = $database->getConnexion();
    $liaison = new Relier($db);
    $numh=$_GET['numh'];
    $numpres=$_GET['numpres'];
    $prixpres=$_GET['prixpres'];
    
    $newliaison=[
        "numero"=>$numh,
        "numpres"=>$numpres,
        "prixpres"=>$prixpres,
    ];

    $newliaison=json_encode($newliaison);
    $newliaison=json_decode($newliaison);
    #$newliaison = json_decode(file_get_contents("php://input"));
    if(!empty($newliaison)){

        $liaison->numh = $newliaison->numero;
        $liaison->numpres = $newliaison->numpres;
        $liaison->prixpresh = $newliaison->prixpres;
       
        if($liaison->Updateliaison()){
            http_response_code(200);
            echo json_encode(["message" => "La liaison a bien été effectuée"]);
        }else{
            http_response_code(503);
            echo json_encode(["message" => "La liaison n'a pas été effectuée"]);         
        }
    }else{
        echo json_encode(["message" => "La liaison n'a pas été effectuée"]);
    }
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}