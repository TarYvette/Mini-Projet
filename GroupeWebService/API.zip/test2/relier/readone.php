<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER["REQUEST_METHOD"]=='GET'){
    include_once'../config/config.php';
    include_once'../models/relier.php';

    $dbase=new Database();
    $db=$dbase->getconnexion();
    $liaison=new Relier($db);
    $donnees = json_decode(file_get_contents("php://input"));
    $uid=$_GET['uid'];
    if(!empty($uid)){
        $liaison->numh = $uid;
        $liaison->Showone();
        if($liaison->numh != null){

            $liaison = [
                "NUMERO" => $liaison->numh,
                "NUMPRES" => $liaison->numpres,
                "PRIXPRES" => $liaison->prixpres,
                #"categories_nom" => $liaison->categories_nom
            ];
            http_response_code(200);
            echo json_encode($liaison);
        }else{
            http_response_code(404);
            echo json_encode(array("message" => "Cette liaison n'existe pas."));
        }
    }else{
        echo"Aucune Donnée reçue!";
    }

}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}

?>