<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER["REQUEST_METHOD"]=='POST'){
    include_once'../config/config.php';
    include_once'../models/users.php';

    $dbase=new Database();
    $db=$dbase->getconnexion();
    $user=new Client($db);
    $nom=$_GET['nom'];
    $prenom=$_GET['prenom'];
    $adresse=$_GET['adresse'];
    $ville=$_GET['ville'];
    $code=$_GET['code'];
    $pays=$_GET['pays'];
    $tel=$_GET['tel'];
    $mail=$_GET['mail'];
    $pass=$_GET['pass'];

    $newuser=[
        "Nom" => $nom,
        "Prenom" => $prenom,
        "Adresse" => $adresse,
        "Ville" => $ville,
        "CodePostal" => $code,
        "Pays" => $pays,
        "Telephone" => $tel,
        "Email" => $mail,
        "Pass" => $pass
    ];
    $newuser=json_encode($newuser);
    $newuser=json_decode($newuser);
    if(!empty($newuser)){
        #$user->id=$newuser->id;
        $user->nom=$newuser->Nom;
        $user->prenom=$newuser->Prenom;
        $user->adresse=$newuser->Adresse;
        $user->ville=$newuser->Ville;
        $user->cp=$newuser->CodePostal;
        $user->pays=$newuser->Pays;
        $user->tel=$newuser->Telephone;
        $user->mail=$newuser->Email;
        $user->pass=$newuser->Pass;

        if($user->Adduser()){
            http_response_code(200);
            echo json_encode(["message" => "l'utilisateur a bien été enregistré!"]);
        }else{
            http_response_code(503);
            echo json_encode(["message" => "L'ajout du nouvel utilisateur n'a pas été effectué"]);
        }
    }else{
        echo json_encode(["message" => "Aucune à enregistrer!"]);
    }
    
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}

?>