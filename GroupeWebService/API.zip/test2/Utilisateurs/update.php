<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if($_SERVER['REQUEST_METHOD'] == 'PUT'){
    include_once '../config/config.php';
    include_once '../models/users.php';

    $database = new Database();
    $db = $database->getConnexion();
    $user = new Client($db);
    $nom=$_GET['nom'];
    $prenom=$_GET['prenom'];
    $adresse=$_GET['adresse'];
    $ville=$_GET['ville'];
    $code=$_GET['code'];
    $pays=$_GET['pays'];
    $tel=$_GET['tel'];
    $mail=$_GET['mail'];
    $pass=$_GET['pass'];
    $newinfo=[
        "nom"=>$nom,
        "prenom"=>$prenom,
        "adresse"=>$adresse,
        "ville"=>$ville,
        "codepostal"=>$code,
        "pays"=>$pays,
        "telephone"=>$tel,
        "mail"=>$mail,
        "pass"=>$pass
    ];
    $newinfo=json_encode($newinfo);
    $newinfo=json_decode($newinfo);
    #$newinfo = json_decode(file_get_contents("php://input"));
    if(!empty($newinfo)){

        $user->nom = $newinfo->nom;
        $user->prenom = $newinfo->prenom;
        $user->adresse = $newinfo->adresse;
        $user->ville = $newinfo->ville;
        $user->cp = $newinfo->codepostal;
        $user->pays = $newinfo->pays;
        $user->tel = $newinfo->telephone;
        $user->mail = $newinfo->mail;
        $user->pass=$newuser->pass;

        if($user->Updateuser()){
            http_response_code(200);
            echo json_encode(["message" => "La modification a bien été effectuée"]);
        }else{
            http_response_code(503);
            echo json_encode(["message" => "La modification n'a pas été effectuée"]);         
        }
    }else{
        echo json_encode(["message" => "Aucune donnée reçue!"]);
    }
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}