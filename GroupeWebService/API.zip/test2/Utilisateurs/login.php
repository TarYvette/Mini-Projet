<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if($_SERVER["REQUEST_METHOD"]=='GET'){
    include_once '../config/config.php';
    include_once '../models/users.php';
    $dbase=new Database();
    $db=$dbase->getconnexion();

    $user=new Client($db);
    $mail=$_GET['mail'];
    $pass=$_GET['pass'];
    $user->mail=$mail;
    $stmt=$user->login();
    
    if(!empty($stmt)){
        extract($stmt);
        $word=$PASSCLIENT;
        if($word==$pass){
            http_response_code(200);
            echo json_encode(["message" => "Succes : E-mail et Mot de passe corrects!"]);
        }else{
            echo json_encode(["message" => "Erreur: Mot de passe incorrect!"]);
        }
    }else{
        echo json_encode(["message" => "Erreur: L'adresse E-mail entrée est incorrect!"]);
    }
}else{
    http_response_code(405);
    echo json_encode(["message" => "La méthode utilisée n'est pas autorisée"]);
}
?>