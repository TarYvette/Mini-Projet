<?php 
require("config.php"); 

if(isset($_REQUEST['submit']) and $_REQUEST['submit']!=""){
    extract($_REQUEST);
    if($LIB_PHASE==""){
        header('location:'.$_SERVER['PHP_SELF'].'?msg=un');
        exit;
    }else if($DESC_PHASE==""){
        header('location:'.$_SERVER['PHP_SELF'].'?msg=un');
        exit;
    }else if($DATE_D==""){
        header('location:'.$_SERVER['PHP_SELF'].'?msg=un');
        exit;
    }else if($DATE_F==""){
        header('location:'.$_SERVER['PHP_SELF'].'?msg=un');
        exit;
    }else if($MONTANT==""){
        header('location:'.$_SERVER['PHP_SELF'].'?msg=un');
        exit;
    }else{
        
        $userCount  =   $db->getQueryCount('phase','CODE_PHASE');
        $data   =   array(
                        'LIB_PHASE'=>$LIB_PHASE,
                        'DESC_PHASE'=>$DESC_PHASE,
                        'DATE_D'=>$DATE_D,
                        'DATE_F'=>$DATE_F,
                        'MONTANT'=>$MONTANT,
                    );
        try {
            $insert =   $db->insert('phase',$data);
            if($insert){
                header('location:phase-afficher.php?msg=ras');
                exit;
            }else{
                header('location:phase-afficher.php?msg=rna');
                exit;
            }
        } catch (Exception $e) {
            header('location:'.$_SERVER['PHP_SELF'].'?msg=rna');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Progest</title>

    <!-- Styles -->
    <link href="bc/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="bc/chartist.min.css" rel="stylesheet">
    <link href="bc/font-awesome.min.css" rel="stylesheet">
    <link href="bc/themify-icons.css" rel="stylesheet">
    <link href="bc/owl.carousel.min.css" rel="stylesheet" />
    <link href="bc/owl.theme.default.min.css" rel="stylesheet" />
    <link href="bc/weather-icons.css" rel="stylesheet" />
    <link href="bc/sidebar.css" rel="stylesheet">
    <link href="bc/bootstrap.min.css" rel="stylesheet">
    <link href="bc/helper.css" rel="stylesheet">
    <link href="bc/style.css" rel="stylesheet">

</head>
<body>


<?php 
require("menu.php"); 
?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
    <!-- /# row -->
                <section id="tablecontent">
                    <div class="container">
                        <?php

                        if(isset($_REQUEST['msg']) and $_REQUEST['msg']=="un"){
                            echo    '<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Tout les champs obligatoire doivent etre renseigner !</div>';
                        }elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ras"){
                            echo    '<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Entrée ajouté avec succès!</div>';
                        }elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rna"){
                            echo    '<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Entrée non ajouté. <strong>S\'il vous plait, réessayer!</strong></div>';
                        }

                        ?>

                        <div class="card">

                            <div class="card-header"><i class="fa fa-fw fa-plus-circle"></i> <strong>Ajouter une entree</strong> </div>

                            <div class="card-body">

                                <div class="col-sm-6">
                                    <h5 class="card-title">Les champs avec <span class="text-danger">*</span> sont obligatoires !</h5>
                                    <form method="post">
                                        <div class="form-group">
                                            <label>Libelle <span class="text-danger">*</span></label>
                                            <input type="text" name="LIB_PHASE" id="LIB_PHASE" class="form-control" placeholder="Entrez le libelle" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Description <span class="text-danger">*</span></label>
                                            <input type="text" name="DESC_PHASE" id="DESC_PHASE" class="form-control" placeholder="Entrez la description" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Date debut <span class="text-danger">*</span></label>
                                            <input type="date" name="DATE_D" id="DATE_D" class="form-control" placeholder="Entrez la date de debut" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Date fin <span class="text-danger">*</span></label>
                                            <input type="date" name="DATE_F" id="DATE_F" class="form-control" placeholder="Entrez la date de fin" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Montant <span class="text-danger">*</span></label>
                                            <input type="number" name="MONTANT" id="MONTANT" class="form-control" placeholder="Entrez le montant" required>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" name="submit" value="submit" id="submit" class="btn btn-primary"><i class="fa fa-fw fa-plus-circle"></i> Ajouter</button>
                                        </div>
                                    </form>
                                </div>

                            </div>

                        </div>

                    </div>
                </section>
            </div>
        </div>
    </div>
    

<!-- jquery vendor -->
    <script src="bt/jquery-3.6.0.js"></script>
    <script src="bt/jquery.min.js"></script>
    <script src="bt/jquery.nanoscroller.min.js"></script>
    <!-- nano scroller -->
    <script src="bt/sidebar.js"></script>
    <script src="bt/pace.min.js"></script>
    <!-- sidebar -->

    <script src="bt/bootstrap.min.js"></script>
    <script src="bt/scripts.js"></script>
    <!-- bootstrap -->

    <script src="bt/jquery.simpleWeather.min.js"></script>
    <script src="bt/weather-init.js"></script>
    <script src="bt/circle-progress.min.js"></script>
    <script src="bt/circle-progress-init.js"></script>
    <script src="bt/chartist.min.js"></script>
    <script src="bt/jquery.sparkline.min.js"></script>
    <script src="bt/sparkline.init.js"></script>
    <script src="bt/owl.carousel.min.js"></script>
    <script src="bt/owl.carousel-init.js"></script>
    <!-- scripit init-->
    <script src="bt/dashboard2.js"></script>
</body>



</html>