<?php 
include_once('config.php');

if(isset($_REQUEST['delId']) and $_REQUEST['delId']!=""){
	$db->delete('livrable',array('CODE_LIV'=>$_REQUEST['delId']));
	header('location: livrable-afficher.php?msg=rds');
	exit;
}
?>