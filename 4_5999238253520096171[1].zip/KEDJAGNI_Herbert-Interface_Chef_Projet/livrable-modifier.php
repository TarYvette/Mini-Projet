<?php 
require("config.php"); 


if(isset($_REQUEST['editId']) and $_REQUEST['editId']!=""){
    $row    =   $db->getAllRecords('livrable','*',' AND CODE_LIV="'.$_REQUEST['editId'].'"');
}

if(isset($_REQUEST['submit']) and $_REQUEST['submit']!=""){
    extract($_REQUEST);
    if($CODE_PHASE==""){
        header('location:'.$_SERVER['PHP_SELF'].'?msg=un');
        exit;
    }else if($LIB_LIV==""){
        header('location:'.$_SERVER['PHP_SELF'].'?msg=un');
        exit;
    }else if($DESCRIP_LIV==""){
        header('location:'.$_SERVER['PHP_SELF'].'?msg=un');
        exit;
    }else if($CHEMIN_LIV==""){
        header('location:'.$_SERVER['PHP_SELF'].'?msg=un');
        exit;
    }else{
        $data   =   array(
                        'CODE_PHASE'=>$CODE_PHASE,
                        'LIB_LIV'=>$LIB_LIV,
                        'DESCRIP_LIV'=>$DESCRIP_LIV,
                        'CHEMIN_LIV'=>$CHEMIN_LIV,
                    );
        try {
            $update =   $db->update('livrable',$data,array('CODE_LIV'=>$editId));
            if($update){
                header('location:livrable-afficher.php?msg=ras');
                exit;
            }else{
                header('location:livrable-afficher.php?msg=rna');
                exit;
            }
        } catch (Exception $e) {
            header('location:'.$_SERVER['PHP_SELF'].'?msg=rna');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Progest</title>

    <!-- Styles -->
    <link href="bc/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="bc/chartist.min.css" rel="stylesheet">
    <link href="bc/font-awesome.min.css" rel="stylesheet">
    <link href="bc/themify-icons.css" rel="stylesheet">
    <link href="bc/owl.carousel.min.css" rel="stylesheet" />
    <link href="bc/owl.theme.default.min.css" rel="stylesheet" />
    <link href="bc/weather-icons.css" rel="stylesheet" />
    <link href="bc/sidebar.css" rel="stylesheet">
    <link href="bc/bootstrap.min.css" rel="stylesheet">
    <link href="bc/helper.css" rel="stylesheet">
    <link href="bc/style.css" rel="stylesheet">

</head>
<body>


<?php 
require("menu.php"); 
?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
    <!-- /# row -->
                <section id="tablecontent">
                    <div class="container">
                        <?php

                        if(isset($_REQUEST['msg']) and $_REQUEST['msg']=="un"){
                            echo    '<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Tout les champs obligatoire doivent etre renseigner !</div>';
                        }elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ras"){
                            echo    '<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Entrée ajouté avec succès!</div>';
                        }elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rna"){
                            echo    '<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Entrée non ajouté. <strong>S\'il vous plait, réessayer!</strong></div>';
                        }

                        ?>

                        <div class="card">

                            <div class="card-header"><i class="fa fa-fw fa-plus-circle"></i> <strong>Modifier une entree</strong> </div>

                            <div class="card-body">

                                <div class="col-sm-6">
                                    <h5 class="card-title">Les champs avec <span class="text-danger">*</span> sont obligatoires !</h5>
                                    <form method="post">
                                        <div class="form-group">
                                            <label>Code Phase <span class="text-danger">*</span></label>
                                            <input type="text" name="CODE_PHASE" id="CODE_PHASE" class="form-control" value="<?php echo $row[0]['CODE_PHASE']; ?>"   placeholder="Entrez le code de la phase" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Libelle <span class="text-danger">*</span></label>
                                            <input type="text" name="LIB_LIV" id="LIB_LIV" class="form-control" value="<?php echo $row[0]['LIB_LIV']; ?>"   placeholder="Entrez le libelle" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Description <span class="text-danger">*</span></label>
                                            <input type="text" name="DESCRIP_LIV" id="DESCRIP_LIV" class="form-control" value="<?php echo $row[0]['DESCRIP_LIV']; ?>"   placeholder="Entrez la description" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Chemin <span class="text-danger">*</span></label>
                                            <input type="text" name="CHEMIN_LIV" id="CHEMIN_LIV" class="form-control" value="<?php echo $row[0]['CHEMIN_LIV']; ?>"   placeholder="Entrez le chemin" required>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" name="submit" value="submit" id="submit" class="btn btn-primary"><i class="fa fa-fw fa-plus-circle"></i> Modifier</button>
                                        </div>
                                    </form>
                                </div>

                            </div>

                        </div>

                    </div>
                </section>
            </div>
        </div>
    </div>
    

<!-- jquery vendor -->
    <script src="bt/jquery-3.6.0.js"></script>
    <script src="bt/jquery.min.js"></script>
    <script src="bt/jquery.nanoscroller.min.js"></script>
    <!-- nano scroller -->
    <script src="bt/sidebar.js"></script>
    <script src="bt/pace.min.js"></script>
    <!-- sidebar -->

    <script src="bt/bootstrap.min.js"></script>
    <script src="bt/scripts.js"></script>
    <!-- bootstrap -->

    <script src="bt/jquery.simpleWeather.min.js"></script>
    <script src="bt/weather-init.js"></script>
    <script src="bt/circle-progress.min.js"></script>
    <script src="bt/circle-progress-init.js"></script>
    <script src="bt/chartist.min.js"></script>
    <script src="bt/jquery.sparkline.min.js"></script>
    <script src="bt/sparkline.init.js"></script>
    <script src="bt/owl.carousel.min.js"></script>
    <script src="bt/owl.carousel-init.js"></script>
    <!-- scripit init-->
    <script src="bt/dashboard2.js"></script>
</body>



</html>