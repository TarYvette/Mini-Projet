<?php 
include_once('config.php');

if(isset($_REQUEST['delId']) and $_REQUEST['delId']!=""){
	$db->delete('phase',array('CODE_PHASE'=>$_REQUEST['delId']));
	header('location: phase-afficher.php?msg=rds');
	exit;
}
?>