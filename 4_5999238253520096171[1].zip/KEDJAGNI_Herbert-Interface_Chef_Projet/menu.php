<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
        <div class="nano">
            <div class="nano-content">
                <ul>
                    <div class="logo"><a href="index.php"><span>PROGEST</span></a></div>
                    <li class="label">Menus</li>
                    <li><a class="sidebar-sub-toggle" href="index.php"><i class="ti-home"></i>Tableau de bord 
                    </li></a>

                   <li class="label">Projets</li>
                 
                    <li><a class="sidebar-sub-toggle"><i class="ti-bar-chart-alt"></i> Afficher<span
                                class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>
                            <li><a href="#">Tout</a></li>
                            <li><a href="#">Etat</a></li>
                            <li><a href="#">En cours</a></li>
                            <li><a href="#">Terminé</a></li>
                        </ul>
                    </li>
                      
                    <li><a href="#"><i class=""></i> Modifier </a></li>
                    <li><a href="#"><i class=""></i> Ajouter</a></li>

                    <li class="label">Phases</li>
                     <li><a href="phase-afficher.php"><i class="ti-bar-chart-alt"></i> Afficher</a>
                    </li>
                    <li><a href="phase-ajouter.php"><i class="ti-user"></i> Ajouter</a></li>

                    <li class="label">Livrables</li>
                     <li><a href="livrable-afficher.php"><i class="ti-bar-chart-alt"></i> Afficher</a>
                    </li>
                    <li><a href="livrable-ajouter.php"><i class="ti-user"></i> Ajouter</a></li>

                    <li class="label">Organismes</li>
                     <li><a href="#"><i class="ti-bar-chart-alt"></i> Afficher</a>
                    </li>
                    <li><a href="#"><i class="ti-user"></i> Ajouter</a></li>
                    <li><a href="#"><i class="ti-layout-grid2-alt"></i> Modifier</a></li>
                   
                    <li class="label">Actions</li>
                    
                    <li><a href="#"><i class="ti-files"></i> imprimer</a></li>
                    <li><a><i class="ti-close"></i> Deconnecter</a></li>
                </ul>
            </div>
        </div>
</div>

<div class="header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="float-left">
                        <div class="hamburger sidebar-toggle">
                            <span class="line"></span>
                            <span class="line"></span>
                            <span class="line"></span>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
</div>