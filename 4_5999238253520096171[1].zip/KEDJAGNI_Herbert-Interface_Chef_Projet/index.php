<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Progest</title>

    <!-- Styles -->
    <link href="bc/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="bc/chartist.min.css" rel="stylesheet">
    <link href="bc/font-awesome.min.css" rel="stylesheet">
    <link href="bc/themify-icons.css" rel="stylesheet">
    <link href="bc/owl.carousel.min.css" rel="stylesheet" />
    <link href="bc/owl.theme.default.min.css" rel="stylesheet" />
    <link href="bc/weather-icons.css" rel="stylesheet" />
    <link href="bc/sidebar.css" rel="stylesheet">
    <link href="bc/bootstrap.min.css" rel="stylesheet">
    <link href="bc/helper.css" rel="stylesheet">
    <link href="bc/style.css" rel="stylesheet">

</head>
<body>


<?php 
require("menu.php"); 
require("config.php"); 
?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
    <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="card">
                                <div class="stat-widget-one">
                                    <div class="stat-icon dib"><i class="ti-money color-success border-success"></i>
                                    </div>
                                    <div class="stat-content dib">
                                        <div class="stat-text">Projet en cours</div>
                                        <div class="stat-digit">100</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="card">
                                <div class="stat-widget-one">
                                    <div class="stat-icon dib"><i class="ti-user color-primary border-primary"></i>
                                    </div>
                                    <div class="stat-content dib">
                                        <div class="stat-text">Projet terminés</div>
                                        <div class="stat-digit">961</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="card">
                                <div class="stat-widget-one">
                                    <div class="stat-icon dib"><i class="ti-layout-grid2 color-pink border-pink"></i>
                                    </div>
                                    <div class="stat-content dib">
                                        <div class="stat-text">Nombreclients</div>
                                        <div class="stat-digit">770</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="card">
                                <div class="stat-widget-one">
                                    <div class="stat-icon dib"><i class="ti-link color-danger border-danger"></i></div>
                                    <div class="stat-content dib">
                                        <div class="stat-text">Nouveau projet</div>
                                        <div class="stat-digit">2,781</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    

<!-- jquery vendor -->
    <script src="bt/jquery-3.6.0.js"></script>
    <script src="bt/jquery.min.js"></script>
    <script src="bt/jquery.nanoscroller.min.js"></script>
    <!-- nano scroller -->
    <script src="bt/sidebar.js"></script>
    <script src="bt/pace.min.js"></script>
    <!-- sidebar -->

    <script src="bt/bootstrap.min.js"></script>
    <script src="bt/scripts.js"></script>
    <!-- bootstrap -->

    <script src="bt/jquery.simpleWeather.min.js"></script>
    <script src="bt/weather-init.js"></script>
    <script src="bt/circle-progress.min.js"></script>
    <script src="bt/circle-progress-init.js"></script>
    <script src="bt/chartist.min.js"></script>
    <script src="bt/jquery.sparkline.min.js"></script>
    <script src="bt/sparkline.init.js"></script>
    <script src="bt/owl.carousel.min.js"></script>
    <script src="bt/owl.carousel-init.js"></script>
    <!-- scripit init-->
    <script src="bt/dashboard2.js"></script>
</body>



</html>