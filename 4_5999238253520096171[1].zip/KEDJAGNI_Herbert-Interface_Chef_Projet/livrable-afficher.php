<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Progest</title>

    <!-- Styles -->
    <link href="bc/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="bc/chartist.min.css" rel="stylesheet">
    <link href="bc/font-awesome.min.css" rel="stylesheet">
    <link href="bc/themify-icons.css" rel="stylesheet">
    <link href="bc/owl.carousel.min.css" rel="stylesheet" />
    <link href="bc/owl.theme.default.min.css" rel="stylesheet" />
    <link href="bc/weather-icons.css" rel="stylesheet" />
    <link href="bc/sidebar.css" rel="stylesheet">
    <link href="bc/bootstrap.min.css" rel="stylesheet">
    <link href="bc/helper.css" rel="stylesheet">
    <link href="bc/style.css" rel="stylesheet">

</head>
<body>


<?php 
require("menu.php"); 
require("config.php"); 
$rowData =   $db->getAllRecords('livrable','*','','');
?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
    <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="card">
                                <div class="stat-widget-one">
                                    <div class="stat-icon dib"><i class="ti-money color-success border-success"></i>
                                    </div>
                                    <div class="stat-content dib">
                                        <div class="stat-text">Livrables</div>
                                        <div class="stat-digit"><?php echo count($rowData); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section id="tablecontent">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr class="bg-primary text-white">
                                <th>Code Livrable</th>
                                <th>Code Phase</th>
                                <th>Libelle</th>
                                <th>Description</th>
                                <th>Chemin</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if(count($rowData)>0){
                                $s  =   '';
                                foreach($rowData as $val){
                                    $s++;
                            ?>
                            <tr>
                                <td><?php echo $val['CODE_LIV'];?></td>
                                <td><?php echo $val['CODE_PHASE'];?></td>
                                <td><?php echo $val['LIB_LIV'];?></td>
                                <td><?php echo $val['DESCRIP_LIV'];?></td>
                                <td><?php echo $val['CHEMIN_LIV'];?></td>
                                <td align="center">
                                    <a href="livrable-modifier.php?editId=<?php echo $val['CODE_LIV'];?>" class="text-primary">Modifier</a> | 
                                    <a href="livrable-delete.php?delId=<?php echo $val['CODE_LIV'];?>" class="text-danger" onClick="return confirm('Etes-vous sure de vouloir supprimer cette entrée ?');">Supprimer</a>
                                </td>

                            </tr>
                            <?php 
                                }
                            }else{
                            ?>
                            <tr><td colspan="6" align="center">Aucun résultat trouvé!</td></tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </section>
            </div>
        </div>
    </div>
    

<!-- jquery vendor -->
    <script src="bt/jquery-3.6.0.js"></script>
    <script src="bt/jquery.min.js"></script>
    <script src="bt/jquery.nanoscroller.min.js"></script>
    <!-- nano scroller -->
    <script src="bt/sidebar.js"></script>
    <script src="bt/pace.min.js"></script>
    <!-- sidebar -->

    <script src="bt/bootstrap.min.js"></script>
    <script src="bt/scripts.js"></script>
    <!-- bootstrap -->

    <script src="bt/jquery.simpleWeather.min.js"></script>
    <script src="bt/weather-init.js"></script>
    <script src="bt/circle-progress.min.js"></script>
    <script src="bt/circle-progress-init.js"></script>
    <script src="bt/chartist.min.js"></script>
    <script src="bt/jquery.sparkline.min.js"></script>
    <script src="bt/sparkline.init.js"></script>
    <script src="bt/owl.carousel.min.js"></script>
    <script src="bt/owl.carousel-init.js"></script>
    <!-- scripit init-->
    <script src="bt/dashboard2.js"></script>
</body>



</html>